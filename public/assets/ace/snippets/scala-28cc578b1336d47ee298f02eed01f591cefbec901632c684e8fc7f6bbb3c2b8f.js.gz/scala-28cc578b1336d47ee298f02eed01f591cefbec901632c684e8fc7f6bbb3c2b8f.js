define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./scala.snippets");
exports.scope = "scala";

});
