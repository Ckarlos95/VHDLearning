define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./julia.snippets");
exports.scope = "julia";

});
