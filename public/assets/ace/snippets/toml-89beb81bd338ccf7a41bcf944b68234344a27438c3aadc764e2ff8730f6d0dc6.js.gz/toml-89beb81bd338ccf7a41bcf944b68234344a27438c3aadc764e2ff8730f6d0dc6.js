define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./toml.snippets");
exports.scope = "toml";

});
