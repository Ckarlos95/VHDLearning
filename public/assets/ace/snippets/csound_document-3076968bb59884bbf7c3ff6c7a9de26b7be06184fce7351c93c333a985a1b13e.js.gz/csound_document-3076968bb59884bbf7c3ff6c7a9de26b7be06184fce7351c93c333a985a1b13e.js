define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./csound_document.snippets");
exports.scope = "csound_document";

});
