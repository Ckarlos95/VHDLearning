define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./tex.snippets");
exports.scope = "tex";

});
