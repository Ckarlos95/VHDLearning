define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./wollok.snippets");
exports.scope = "wollok";

});
