define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./twig.snippets");
exports.scope = "twig";

});
