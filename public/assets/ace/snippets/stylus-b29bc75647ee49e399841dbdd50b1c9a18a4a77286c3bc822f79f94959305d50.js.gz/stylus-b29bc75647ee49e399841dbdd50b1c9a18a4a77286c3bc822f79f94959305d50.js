define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./stylus.snippets");
exports.scope = "stylus";

});
