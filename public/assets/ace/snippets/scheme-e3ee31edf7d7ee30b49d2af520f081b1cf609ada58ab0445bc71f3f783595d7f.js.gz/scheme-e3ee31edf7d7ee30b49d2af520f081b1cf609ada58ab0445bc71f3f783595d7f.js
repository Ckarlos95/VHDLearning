define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./scheme.snippets");
exports.scope = "scheme";

});
