define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./mushcode_high_rules.snippets");
exports.scope = "mushcode_high_rules";

});
