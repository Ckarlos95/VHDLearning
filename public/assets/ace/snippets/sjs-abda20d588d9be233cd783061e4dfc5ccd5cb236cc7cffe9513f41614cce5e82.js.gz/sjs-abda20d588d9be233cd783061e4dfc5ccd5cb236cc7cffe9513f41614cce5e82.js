define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./sjs.snippets");
exports.scope = "sjs";

});
