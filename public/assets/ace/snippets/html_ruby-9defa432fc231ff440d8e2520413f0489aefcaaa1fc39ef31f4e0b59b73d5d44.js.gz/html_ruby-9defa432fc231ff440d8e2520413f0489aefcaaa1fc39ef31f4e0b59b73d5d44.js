define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./html_ruby.snippets");
exports.scope = "html_ruby";

});
