/*!
 * async.js
 * Copyright(c) 2010 Fabian Jakobs <fabian.jakobs@web.de>
 * MIT Licensed
 */


define(function(require, exports, module) {
    
module.exports = require("./async")
module.exports.test = require("./test")
require("./utils")

})
;
