define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./textile.snippets");
exports.scope = "textile";

});
