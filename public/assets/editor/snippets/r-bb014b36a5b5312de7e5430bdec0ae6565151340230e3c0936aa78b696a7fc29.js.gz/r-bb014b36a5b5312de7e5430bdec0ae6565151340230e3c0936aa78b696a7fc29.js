define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./r.snippets");
exports.scope = "r";

});
