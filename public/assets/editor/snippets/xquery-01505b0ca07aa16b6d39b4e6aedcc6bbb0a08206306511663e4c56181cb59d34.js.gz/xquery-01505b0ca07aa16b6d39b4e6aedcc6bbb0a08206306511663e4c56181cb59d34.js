define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./xquery.snippets");
exports.scope = "xquery";

});
