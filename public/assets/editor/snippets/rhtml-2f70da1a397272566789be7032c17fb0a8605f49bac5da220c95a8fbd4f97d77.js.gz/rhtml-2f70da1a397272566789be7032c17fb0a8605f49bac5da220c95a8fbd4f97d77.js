define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./rhtml.snippets");
exports.scope = "rhtml";

});
