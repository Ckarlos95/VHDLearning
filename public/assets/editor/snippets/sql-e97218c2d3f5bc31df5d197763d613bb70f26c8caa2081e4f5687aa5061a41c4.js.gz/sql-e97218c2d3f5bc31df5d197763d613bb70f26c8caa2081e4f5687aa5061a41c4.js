define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./sql.snippets");
exports.scope = "sql";

});
