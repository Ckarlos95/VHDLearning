define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./csound_orchestra.snippets");
exports.scope = "csound_orchestra";

});
