define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./graphqlschema.snippets");
exports.scope = "graphqlschema";

});
