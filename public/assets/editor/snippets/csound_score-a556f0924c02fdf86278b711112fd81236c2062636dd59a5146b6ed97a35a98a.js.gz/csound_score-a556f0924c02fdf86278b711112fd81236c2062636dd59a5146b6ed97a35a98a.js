define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./csound_score.snippets");
exports.scope = "csound_score";

});
