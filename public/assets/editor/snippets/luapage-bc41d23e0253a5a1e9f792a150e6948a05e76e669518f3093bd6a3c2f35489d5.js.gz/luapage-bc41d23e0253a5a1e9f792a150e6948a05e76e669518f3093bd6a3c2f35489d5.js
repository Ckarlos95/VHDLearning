define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./luapage.snippets");
exports.scope = "luapage";

});
