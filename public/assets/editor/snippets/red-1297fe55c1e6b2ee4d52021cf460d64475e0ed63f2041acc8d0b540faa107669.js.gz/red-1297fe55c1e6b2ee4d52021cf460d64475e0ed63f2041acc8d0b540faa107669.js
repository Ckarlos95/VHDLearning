define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./red.snippets");
exports.scope = "red";

});
