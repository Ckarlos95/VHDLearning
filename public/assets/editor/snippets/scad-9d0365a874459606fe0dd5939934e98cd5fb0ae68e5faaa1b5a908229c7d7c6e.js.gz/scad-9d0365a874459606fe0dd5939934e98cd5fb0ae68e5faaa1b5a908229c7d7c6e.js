define(function(require, exports, module) {
"use strict";

exports.snippetText = require("../requirejs/text!./scad.snippets");
exports.scope = "scad";

});
